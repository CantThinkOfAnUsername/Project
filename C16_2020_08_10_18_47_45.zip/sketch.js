var banana, bananaImg, BG, backgroundImg, score, monkey,monkeyImg, obstacleImg, ground, invisibleGround;
function preload(){
  banana = loadImage("banana.png");
  backgroundImg = loadImage("jungle.png");
  monkeyImg = loadAnimation("Monkey_01.png","Monkey_02.png", "Monkey_03.png", "Monkey_04.png", "Monkey_05.png","Monkey_06.png", "Monkey_07.png", "Monkey_08.png","Monkey_09.png", "Monkey_10.png")
  obstacleImg = loadImage("stone.png")
}
function setup() {
  createCanvas(400, 400);
  BG = createSprite(200,200,400,400)
  ground = createSprite(200,390,400,5) 
  invisibleGround = createSprite(200,395,400,5) 
  monkey = createSprite(100,390,20,20)
}
function draw() {
  invisibleGround.visible = false;
  monkey.collide(invisibleGround);
  spawnRocks();
  ground.velocityX = -5;
  if (ground.x<0){
      ground.x = ground.width/2
      }
  if(keyDown("SPACE")){
  monkey.velocityY = -5
  }
  monkey.velocityY = monkey.velocityY+0.8
  monkey.setAnimation(monkeyImg)
  
  
}
function spawnRocks() {
  if(frameCount % 80 === 0) {
    var obstacle = createSprite(400,385,10,40);
    obstacle.addImage(obstacleImg);
    obstacle.
    obstacle.velocityX = -4;
  }
}
function spawnBananas() {
  if(frameCount % 60 === 0) {
    banana=createSprite(400,random(340,370),10,40);
    obstacle.addImage(bananaImg);
    obstacle.
    obstacle.velocityX = -4;
  }
}